import kivy                         # imports regarding the GUI (kivy.*)
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput    
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
from kivy.uix.slider import Slider
from kivy.uix.floatlayout import FloatLayout
from kivy.garden import Joystick
from kivy.clock import Clock
from kivy.uix.screenmanager import ScreenManager, Screen
import kivy.config
import socket                       # socket import to establish connecction and send udp packages

UDPClientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)      # start the udp client socket

try:                                # attempt to find the local network (LAN) IP by using a mask
    UDPClientSocket.connect(('192.255.255.255', 1))
    droneIP = UDPClientSocket.getsockname()[0]      # set the IP variable
except:
    droneIP = '127.0.0.1'                    # if we can't find the IP of the network => set it to the most common IP

droneIP = droneIP[:-1] + '1'            # replace the last digit of the IP with 1 since its a constant for the arduino  

serverAddressPort = (droneIP, 2390)         # set the address that we are going to send the Udp packages to

bufferSize = 1024               # set variables for the network
Ssid = ""
Password = "" 

class MainMenu(Screen):             # create the MainMenu class for our app (MAIN CONTROL SCREEN)

    rotateLeftID = ObjectProperty(None)                 # Get the required elements from the screen by their id (buttons(2), slider, switch, joystick {accordingly})
    rotateRightID = ObjectProperty(None)                # button for rotating the drone to the right
    sliderID = ObjectProperty(None)                     # power controlling slider element
    switchID = ObjectProperty(None)                     # ON/OFF switch
    directionsJoystickID = ObjectProperty(None)         # joystick for controlling the mmovement of the drone

    def __init__(self, **kwargs):                           # function runs when the class is created
        super(MainMenu, self).__init__(**kwargs)
        Clock.schedule_interval(self.send_packaged_data, 0.001)                     # activate a clock to run send_packaged_data() every 0.0001 seconds
        self.initial_loop = Clock.schedule_interval(self.initial_disable, 0.1)      # call a function to attempt disabling the buttons
    
    def power_slider(self, widget):                                        # a function to send the value of the power slider to the arduino
        values = "P" + str(round(widget.value))                        # store the message in a variable
        encoded = str.encode(values)                                   # encode the power value message
        UDPClientSocket.sendto(encoded, serverAddressPort)             # send the now encoded message to the arduino
    
    def initial_disable(self, *args):                                      # a function to run when entering the screen to disable all the buttons and other elements
        try:
            self.directionsJoystickID.disabled = True               # disable all the elements
            self.rotateLeftID.disabled = True
            self.rotateRightID.disabled = True
            self.sliderID.disabled = True
            self.initial_loop.cancel()                             # cancel the clock schedule
        except: pass
    
    def switch_input(self, widget):                  # a function that enables or disables the buttons and other elements depending on the status of the ON/OFF switch
        if(widget.active == False):
            self.directionsJoystickID.disabled = True
            self.rotateLeftID.disabled = True
            self.rotateRightID.disabled = True
            self.sliderID.disabled = True
            self.sliderID.value = 1000;
        else:
            encoded = str.encode("S")
            UDPClientSocket.sendto(encoded, serverAddressPort) 
            self.directionsJoystickID.disabled = False
            self.rotateLeftID.disabled = False
            self.rotateRightID.disabled = False
            self.sliderID.disabled = False
        

    def send_packaged_data(self, *args):                    # function that sends encoded packages to the arduino with the movement information
        if self.switchID.active == False: return      # don't send anything if the switch is OFF

        package = str.encode("X")                 # create the encoded message with the appropriate values
        package += int.to_bytes(int(self.directionsJoystickID.pad[0]*1000/2 + 1500), 2, 'little')
        package += str.encode("Y")
        package += int.to_bytes(int(self.directionsJoystickID.pad[1]*-1000/2 + 1500), 2, 'little')
        if self.rotateLeftID.state == "normal":
            package+= "LF".encode()
        elif self.rotateLeftID.state == "down":
            package+= "LT".encode()
        if self.rotateRightID.state == "normal":
            package+= "RF".encode()
        elif self.rotateRightID.state == "down":
            package+= "RT".encode()
        package+= "P".encode()
        package += int.to_bytes(int(self.sliderID.value), 2, 'little')
        UDPClientSocket.sendto(package, serverAddressPort)          # send the message as an Udp package to the arduino 

class WifiOptionsMenu(Screen):              # class WifiOptionsMenu which is the first screen when the app is opened (Allows the user to change the configuration of the arduino's hotspot)

    def change_configuration(self, ssid, password, app):        # function that is called when the 'Change' button is pressed (Sends encoded  
                                                                # data to the arduino containing the new configuration settings for the hotspot)

        if len(ssid) >= 8 and len(password) >= 8:                # require the ssid(network name) and password to have at least 8 characters as it is required for a hotspot
            app.root.current = "control"                        # change the screen to the main screen
            Ssid = ssid
            Password = password
            encoded_package = str.encode("N")                       # indificator for the new config
            encoded_package += int.to_bytes(len(Ssid), 1, 'little')     # create the encoded message
            encoded_package += Ssid.encode()
            encoded_package += int.to_bytes(len(Password), 1, 'little')
            encoded_package += Password.encode()
            UDPClientSocket.sendto(encoded_package, serverAddressPort)      # send the encoded message for the new config of the hotspot

class ScreenManagement(ScreenManager):              # create a screen manager class to take care of different screens and transitions between them
    pass

class DroneApp(App):        # Main class of the app
    def build(self):        
        self.icon = "D.png"     # Set the icon of the app
        return super().build()  # run the build of the super(App) class

if __name__ == "__main__":
    DroneApp().run()            # run the app